#include "stm32f10x.h"                  // Device header"
#include "OLED.h"
#include "Delay.h"
#include "inv_mpu.h"

int main(void)
{
	float Pitch,Roll,Yaw;
	OLED_Init();
	MPU6050_DMP_Init();
	OLED_ShowString(1, 1, "P:");
	OLED_ShowString(2, 1, "R:");
	OLED_ShowString(3, 1, "Y:");
	while(1)
	{
		MPU6050_DMP_Get_Data(&Pitch,&Roll,&Yaw);
		OLED_ShowSignedNum(1,3,Pitch,4);
		OLED_ShowSignedNum(2,3,Roll,4);
		OLED_ShowSignedNum(3,3,Yaw,4);
	}
}
